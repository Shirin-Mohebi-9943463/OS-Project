import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.Semaphore;

public class Z {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int numOfVolunteer = input.nextInt();
        Semaphore MrX = new Semaphore(1);
        Semaphore semVolunteer = new Semaphore(3);

        List<Integer> list = new ArrayList<>();
        for (int i = 1; i <= numOfVolunteer; i++) {
            list.add(i);
            Volunteer volunteer = new Volunteer(i, MrX, semVolunteer);
            volunteer.start();
        }
    }

    public static class MrX extends Thread {
        private int volunteerName;
        private Semaphore semaphore;
        private  int sumVolunteer;
        private  int sumX;
        private Message message = new Message();
        private boolean flag;


        public MrX(int i, Semaphore semaphore) {
            this.volunteerName = i;
            this.semaphore = semaphore;
        }

        @Override
        public void run() {
            try {
                semaphore.acquire();
                message.enterRoom(volunteerName);
//                sumX++;
                message.exitRoom(volunteerName);
                flag=true;

            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            semaphore.release();
//            sumX--;
            if (semaphore.availablePermits()==1) {
                sumX = 0;
            }
            if (check(getSum1(),sumX) && flag) {
                flag=false;
                message.sleepMrX();
            }
        }

        public boolean check(int num1, int num2) {
            if( num1 == 0 && num2 == 0)
                return true;
            else return num2 == 0;
        }

        public int getSum1() {
            return sumVolunteer;
        }

        public void setSum1(int sum1) {
            this.sumVolunteer = sum1;
        }
    }

    public static class Volunteer extends Thread {
        private int volunteerName;
        private Semaphore semaphore;
        private Semaphore semVolunteer;
        private Message message = new Message();
        private int sumVolunteer = 0;



        public Volunteer(int i, Semaphore semaphore, Semaphore semVolunteer) {
            this.semVolunteer = semVolunteer;
            this.semaphore = semaphore;
            this.volunteerName = i;
        }

        @Override
        public void run() {
            message.waitingForInterview(volunteerName);
            MrX mrX = new MrX(volunteerName, semaphore);
            try {
                sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            try {
                semVolunteer.acquire();
                message.inHall(volunteerName);
//                sumVolunteer++;

                mrX.start();
                mrX.join();
//                sumVolunteer--;

            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            semVolunteer.release();
            if (semVolunteer.availablePermits()==3)
                mrX.setSum1(0);

        }

//        public void waitingForInterview() {
//            System.out.println(volunteerName + " waiting for interview outside of company");
//        }
//
//        public void inHall() {
//            System.out.println(volunteerName + " in hall");
//        }

    }
    public static class Message {

        public void waitingForInterview(int nameThread){
            System.out.println(nameThread + " Waiting for interview outside of company");
        }
        public void inHall(int nameThread){
            System.out.println(nameThread + " in hall");
        }
        public void enterRoom(int nameThread) {
            System.out.println(nameThread + " Enter room");
        }

        public void exitRoom(int nameThread){
            System.out.println(nameThread + " Exit room");
        }
        public void sleepMrX(){
            System.out.println("Mr X is sleeping");
        }
    }

}
