import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Project {

    private static Queue<Customer> customers;

    public static void main(String[] args)throws FileNotFoundException {
        customers = new LinkedList<>();
        int number_of_supports;
        //input
        File file = new File("input.txt");
        Scanner input = new Scanner(file);
        number_of_supports = Integer.parseInt(input.nextLine());
        while (input.hasNextLine()) {
            String costumer[] = input.nextLine().split(" ");
            customers.add(new Customer(costumer[0], costumer[1], costumer.length == 3));
        }
        ArrayList<Support> supports = new ArrayList<>();
        //create support 1 support 2 .......
        for (int i = 0; i < number_of_supports; i++) {
            supports.add(new Support("Support" + (i + 1)));
        }
        //start each support
        for (int i = 0; i < supports.size(); i++) {
            supports.get(i).start();
        }
    }


    static class Customer extends Thread {

        private String name;
        private String problem;
        private boolean weak_signal;

        public Customer(String name, String problem, boolean weak_signal) {
            this.name = name;
            this.problem = problem;
            this.weak_signal = weak_signal;
        }

        @Override
        public void run() {
            //filling survey
            System.out.println(this.name + " started filling survey.");
            try {
                sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println(this.name + " filled survey.");
            //this part is for sending feedback
            if (send_feedback()) {
                System.out.println(this.name + " started sending feedback.");
                try {
                    sleep(200);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println(this.name + " finished sending feedback.");
            }
            System.out.println(this.name + " ended the call.");
        }

        private boolean send_feedback() {
            return new Random().nextBoolean();
        }

        public String get_name() {
            return name;
        }

        public String getProblem() {
            return problem;
        }

        public boolean isWeak_signal() {
            return weak_signal;
        }
    }

    static class Support extends Thread {
        private String name;
        private static long total_time;

        public Support(String name) {
            this.name = name;
            total_time = 0;
        }

        @Override
        public void run() {
            //the while part is running until the customer list is not empty.
            while (!Project.customers.isEmpty()) {
                //get customer and put it in customer
                Customer customer = Project.customers.remove();
                if (customer == null) {
                    break;
                }
                System.out.println(this.name + " started talking to " + customer.get_name() + " about " + customer.getProblem() + ".");
                //Here according to the problem written in the input the switch case is executed
                long time_spent = 0;
                switch (customer.getProblem()) {
                    case "sale":
                        time_spent = sale(customer);
                        break;
                    case "technical":
                        time_spent = technical(customer);
                        break;
                    case "config":
                        time_spent = config(customer);
                        break;
                    default:
                        break;
                }
                System.out.println(this.name + " finished talking to " + customer.get_name() + " in" + time_spent + " ms and sent him/her to survey.");
                //after calculating time_spent, every customer get started
                customer.start();
                System.out.println(this.name + " went for rest.");
                //this part is for rest
                long rest_time = 100;
                if (total_time > 1000) {
                    rest_time += 500;
                    total_time = 0;
                }
                try {
                    sleep(rest_time);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println(this.name + " came back from rest.");
            }
        }

        private static long sale(Customer customer) {
            long time_spent = 300;
            if (customer.isWeak_signal()) {
                time_spent += 100;
                total_time += time_spent;
                try {
                    sleep(time_spent);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            return time_spent;
        }

        private static long technical(Customer customer) {
            long time_spent = 500;
            if (customer.isWeak_signal()) {
                time_spent += 100;
                total_time += time_spent;
                try {
                    sleep(time_spent);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            return time_spent;
        }

        private static long config(Customer customer) {
            long time_spent = 200;
            if (customer.isWeak_signal()) {
                time_spent += 100;
                total_time += time_spent;
                try {
                    sleep(time_spent);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            return time_spent;
        }
    }
}