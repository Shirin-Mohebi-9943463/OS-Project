import java.util.*;

public class Proj3 {
    public static void main(String[] args) {
        lru lru = new lru();
        lru.input();
        lru.print();
    }
}

class lru {
    Scanner input = new Scanner(System.in);
    int instructions = input.nextInt();
    int ramSize = input.nextInt();
    int pageSize = input.nextInt();
    Queue<Integer> queue = new LinkedList<>();
    int num;
    int pageFault = 0;

    public void input() {
        while (input.hasNext()) {
            num = input.nextInt();
            lru();
        }
    }

    public void lru() {
        int pageNumber = (num / pageSize);
        if (!queue.contains(pageNumber)) {
            pageFault++;
            if (queue.size() >= (ramSize / pageSize)) {
                queue.remove();
            }
            queue.add(pageNumber);
        } else {
            queue.remove(pageNumber);
            queue.add(pageNumber);
        }
    }

    public void print() {
        System.out.println(pageFault);
        for (int i = 0; i <= queue.size(); i++) {
            minValue();
        }
        if (!queue.isEmpty())
            System.out.println(queue.remove());
    }

    public void minValue() {
        int min = Integer.MAX_VALUE;
        int size = queue.size();
        for (int i = 0; i < size; i++) {
            int current = queue.remove();
            if (current <= min) {
                min = current;
            }
            queue.add(current);
        }
        System.out.print(min + " ");
        queue.remove(min);
    }
}
