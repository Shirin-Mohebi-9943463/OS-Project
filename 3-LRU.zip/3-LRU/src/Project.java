import java.util.ArrayList;
import java.util.Scanner;

public class Project {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int size = scanner.nextInt();
        int ram = scanner.nextInt();
        int pageSize = scanner.nextInt();
        ArrayList<Integer> list = new ArrayList<>();
        ArrayList<Integer> pages = new ArrayList<>();
        int page_fault = 0;
        while (scanner.hasNext()) {
            list.add(scanner.nextInt() / pageSize);
        }
        for (int i = 0; i < list.size(); i++) {
            if (!pages.contains(list.get(i))) {
                page_fault = page_fault + 1;
                if (pages.size() == (ram / pageSize)) {
                    pages.remove(0);
                }
                pages.add(list.get(i));
            } else {
                pages.remove(pages.indexOf(list.get(i)));
                pages.add(list.get(i));
            }
        }
        System.out.println(page_fault);
        sort(pages);
    }

    public static void sort(ArrayList<Integer> arrayList) {
        int temp;
        for (int i = 0; i < arrayList.size(); i++) {
            for (int j = i + 1; j < arrayList.size(); j++) {
                if (arrayList.get(i) > arrayList.get(j)) {
                    temp = arrayList.get(i);
                    arrayList.set(i, arrayList.get(j));
                    arrayList.set(j, temp);
                }
            }
        }
        print(arrayList);
    }

    public static void print(ArrayList<Integer> arrayList) {
        for (int i = 0; i < arrayList.size(); i++) {
            System.out.print(arrayList.get(i) + " ");
        }
    }
}
