import java.util.*;
import java.util.concurrent.Semaphore;

import static java.lang.Thread.sleep;

public class Project {

    public static class Volunteer extends Thread {
        private int name;
        private Message message;

        public Volunteer(int name) {
            this.name = name;
            message = new Message();
        }

        @Override
        public void run() {
            try {
                Mrx.checkIfsleep();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            message.waitingForInterview(name);
            try {
                hall.acquire();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            message.inHall(name);
            try {
                main_room.acquire();
                Mrx.time_for_interviewing();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            message.enterRoom(name);
            try {
                Mrx.time_for_interviewing();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            hall.release();
            message.exitRoom(name);
            main_room.release();
        }
    }

    public static class Mrx extends Thread {

        public static void checkIfsleep() throws InterruptedException {
            Message message = new Message();
            if (main_room.availablePermits() == 1 && hall.availablePermits() == 3) {
                message.sleepMrX();
            }
        }


        public static void time_for_interviewing() throws InterruptedException {
            Mrx.sleep(200);
        }
    }

    public static class Message {

        public void waitingForInterview(int nameThread) {
            System.out.println(nameThread + " Waiting for interview outside of company");
        }

        public void inHall(int nameThread) {
            System.out.println(nameThread + " in hall");
        }

        public void enterRoom(int nameThread) {
            System.out.println(nameThread + " Enter room");
        }

        public void exitRoom(int nameThread) {
            System.out.println(nameThread + " Exit room");
        }

        public void sleepMrX() {
            System.out.println("Mr X is sleeping");
        }
    }

    public static Semaphore main_room;
    public static Semaphore hall;
    public static Queue<Volunteer> volunteers = new LinkedList<>();
    public static Mrx mrx = new Mrx();

    public static void main(String[] args) throws InterruptedException {
        Scanner input = new Scanner(System.in);
        int num_volunteer = input.nextInt();
        main_room = new Semaphore(1);
        hall = new Semaphore(3);
        mrx.start();
        for (int i = 1; i <= num_volunteer; i++) {
            Volunteer volunteer = new Volunteer(i);
            volunteers.add(volunteer);
        }
        while (!volunteers.isEmpty()) {
            volunteers.poll().start();
            sleep(400);
        }
    }
}
