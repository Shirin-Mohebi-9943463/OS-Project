import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Project3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int procesSize = input.nextInt();
        int ramSize = input.nextInt();
        int pageSize = input.nextInt();
        int page_fault = 0;
        int ram_frame_size = ramSize / pageSize;
        ArrayList<Integer> pageList = new ArrayList<>();
        int list;
        while (input.hasNext()) {
            list = input.nextInt();
            int pageNumber = list / pageSize;
            page_fault= pagePlacement(pageNumber,pageList,ram_frame_size,page_fault);

        }
        System.out.println(page_fault);
        Collections.sort(pageList);
        for (int page : pageList)
            System.out.print(page + " ");


    }

    public static int pagePlacement(int pageNumber, ArrayList pageList, int ram_frame_size, int page_fault) {
        if (!pageList.contains(pageNumber)) {
            page_fault++;
            if(pageList.size() >= ram_frame_size){
                pageList.remove(0);
            }
            pageList.add(pageNumber);
        }
        else {
            pageList.remove(pageList.indexOf(pageNumber));
            pageList.add(pageNumber);

        }
        return page_fault;
    }
}