import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.Semaphore;

import static java.lang.Thread.sleep;

public class S {

    public static Semaphore sInterviewRoom;
    public static Semaphore sInHall;
    public static Queue<Interviewee> intervieweeQueue;
    public static Interviewer interviewer;

    public static void main(String[] args) throws InterruptedException {
        Random rand = new Random();
        intervieweeQueue = new LinkedList<>();
        sInterviewRoom = new Semaphore(1);
        sInHall = new Semaphore(3);
        System.out.print("Enter the number of interviewees: ");
        Scanner scanner = new Scanner(System.in);
        int intervieweeCount = scanner.nextInt();

        interviewer = new Interviewer("X");
        interviewer.start();

        for (int i = 0; i < intervieweeCount; i++) {
            Interviewee interviewee = new Interviewee("Interviewee " + (i + 1));
            intervieweeQueue.add(interviewee);
        }

        while (!intervieweeQueue.isEmpty()) {
            intervieweeQueue.poll().start();
            sleep(rand.nextInt(250));
        }
    }

    public static class Interviewee extends Thread {
        private String name;
        private Message message;

        public Interviewee(String name) {
            this.name = name;
            message = new Message(name);
        }

        @Override
        public void run() {
            try {

                interviewer.checkForSleeping(message);

                message.waitingForInterview();
                sInHall.acquire();
                message.inHall();
                sInterviewRoom.acquire();
                message.enterRoom();
                interviewer.interviewing();
                sInHall.release();
                message.exitRoom();
                sInterviewRoom.release();

//                interviewer.checkForSleeping(message);

            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public static class Interviewer extends Thread {
        private String name;

        public Interviewer(String name) {
            this.name = name;
        }

        @Override
        public void run() {
//            while (sInterviewRoom.availablePermits() != 1 || sInHall.availablePermits() != 3) {
//            }
//            System.out.println("sleep.....");
        }

        public void checkForSleeping(Message message) throws InterruptedException {
            if (sInterviewRoom.availablePermits() == 1 && sInHall.availablePermits() == 3) {
                message.sleepMrX();
            }

        }

        public void interviewing() throws InterruptedException {
            sleep(200);
        }
    }

    public static class Message {
        public String nameThread;

        public Message(String nameThread) {
            this.nameThread = nameThread;
        }

        public void waitingForInterview() {
            System.out.println(nameThread + " waiting for interview outside of company");
        }

        public void inHall() {
            System.out.println("\u001B[32m" + nameThread + " in hall" + "\u001B[0m");
        }

        public void enterRoom() {
            System.out.println("\u001B[33m" + nameThread + " enter room" + "\u001B[0m");
        }

        public void exitRoom() {
            System.out.println("\u001B[31m" + nameThread + " Exit room" + "\u001B[0m");
        }

        public void sleepMrX() {
            System.out.println("Mr X is sleeping...");
        }
    }

}
